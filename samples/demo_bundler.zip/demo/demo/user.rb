module Demo
  module User
    puts "**** load User ****"
  end
end