module Demo
  class RoleDeco
    puts "**** UserDeco loaded! ****"
  end
end