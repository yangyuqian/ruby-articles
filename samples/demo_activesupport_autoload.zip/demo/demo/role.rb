module Demo
  class Role
    puts "**** Role loaded! *****"
  end
end